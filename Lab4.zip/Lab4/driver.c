#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "BST.h"

int main(int argc, char** argv) {
    nodeT *pRoot = NULL;        //root
    int data;                //holds the int data
   
    //Insertion of new items, reports when done
    printf("Items to insert (-999 to stop): ");
    scanf("%d", &data);
  
        
    while(data != -999){ 
        pRoot = insert(pRoot, data); 
        report(pRoot); //To print about the tree
        printf("Items to insert (-999 to stop): ");
        scanf("%d", &data);
        
    }
    //report(pRoot);
    printTree(pRoot, 0);

    
    printf("Items to delete (-999 to stop): ");
    scanf("%d", &data);
    while(data != -999){  
        pRoot = deleteNode(pRoot, data);
        printTree(pRoot, 0);
        report(pRoot);
        printf("Items to delete (-999 to stop): ");
        scanf("%d", &data);
    }

    return 0;
}