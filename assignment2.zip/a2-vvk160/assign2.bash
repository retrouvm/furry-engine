#!/bin/bash
#assign2

sed -i.sav -Ef assign2.sed "$*"
